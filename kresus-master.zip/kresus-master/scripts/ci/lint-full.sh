#!/bin/bash
set -e

yarn run ci:lint --verbose
