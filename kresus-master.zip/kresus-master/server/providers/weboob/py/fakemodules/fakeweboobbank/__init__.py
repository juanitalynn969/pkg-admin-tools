# -*- coding: utf-8 -*-
"""
Fake Bank module relying on Weboob backend.
"""
from .module import FakeBankModule

__all__ = ['FakeBankModule']
