import {
    In,
    getRepository,
    Entity,
    PrimaryGeneratedColumn,
    JoinColumn,
    Column,
    ManyToOne,
    Repository,
} from 'typeorm';

import User from './users';
import Access from './accesses';
import Transaction from './transactions';
import Setting from './settings';

import {
    assert,
    currency,
    currencyFormatter,
    CurrencyFormatter,
    UNKNOWN_ACCOUNT_TYPE,
    shouldIncludeInBalance,
    shouldIncludeInOutstandingSum,
    unwrap,
} from '../../helpers';
import { ForceNumericColumn, DatetimeType } from '../helpers';
import { DEFAULT_CURRENCY } from '../../shared/settings';

@Entity('account')
export default class Account {
    private static REPO: Repository<Account> | null = null;

    private static repo(): Repository<Account> {
        if (Account.REPO === null) {
            Account.REPO = getRepository(Account);
        }
        return Account.REPO;
    }

    @PrimaryGeneratedColumn()
    id!: number;

    // ************************************************************************
    // EXTERNAL LINKS
    // ************************************************************************

    @ManyToOne(() => User, { cascade: true, onDelete: 'CASCADE', nullable: false })
    @JoinColumn()
    user!: User;

    @Column('integer')
    userId!: number;

    // Access instance containing the account.
    @ManyToOne(() => Access, { cascade: true, onDelete: 'CASCADE', nullable: false })
    @JoinColumn()
    access!: Access;

    @Column('integer')
    accessId!: number;

    // External (backend) bank module identifier, determining which source to use.
    // TODO could be removed, since this is in the linked access?
    @Column('varchar')
    vendorId!: string;

    // Account number provided by the source. Acts as an id for other models.
    @Column('varchar')
    vendorAccountId!: string;

    // external (backend) type id or UNKNOWN_ACCOUNT_TYPE.
    @Column('varchar', { default: UNKNOWN_ACCOUNT_TYPE })
    type: string = UNKNOWN_ACCOUNT_TYPE;

    // ************************************************************************
    // ACCOUNT INFORMATION
    // ************************************************************************

    // Date at which the account has been imported.
    @Column({ type: DatetimeType })
    importDate!: Date;

    // Balance on the account, at the date at which it has been imported.
    @Column('numeric', { transformer: new ForceNumericColumn() })
    initialBalance!: number;

    // Date at which the account has been polled for the last time.
    @Column({ type: DatetimeType })
    lastCheckDate!: Date;

    // Label describing the account provided by the source.
    @Column('varchar')
    label!: string;

    // description entered by the user.
    @Column('varchar', { nullable: true, default: null })
    customLabel: string | null = null;

    // IBAN provided by the source (optional).
    @Column('varchar', { nullable: true, default: null })
    iban: string | null = null;

    // Currency used by the account.
    @Column('varchar', { nullable: true, default: null })
    currency: string | null = null;

    // If true, this account is not used to eval the balance of an access.
    @Column('boolean', { default: false })
    excludeFromBalance = false;

    // Methods.

    computeBalance = async (): Promise<number> => {
        const ops = await Transaction.byAccount(this.userId, this);
        const today = new Date();
        const s = ops
            .filter(op => shouldIncludeInBalance(op, today, this.type))
            .reduce((sum, op) => sum + op.amount, this.initialBalance);
        return Math.round(s * 100) / 100;
    };

    computeOutstandingSum = async (): Promise<number> => {
        const ops = await Transaction.byAccount(this.userId, this);
        const s = ops
            .filter(op => shouldIncludeInOutstandingSum(op))
            .reduce((sum, op) => sum + op.amount, 0);
        return Math.round(s * 100) / 100;
    };

    getCurrencyFormatter = async (): Promise<CurrencyFormatter> => {
        let checkedCurrency;
        if (currency.isKnown(this.currency)) {
            checkedCurrency = this.currency;
        } else {
            checkedCurrency = (await Setting.findOrCreateDefault(this.userId, DEFAULT_CURRENCY))
                .value;
        }
        assert(checkedCurrency !== null, 'currency is known at this point');
        return currencyFormatter(checkedCurrency);
    };

    // Static methods
    static renamings = {
        initialAmount: 'initialBalance',
        bank: 'vendorId',
        lastChecked: 'lastCheckDate',
        bankAccess: 'accessId',
        accountNumber: 'vendorAccountId',
        title: 'label',
    };

    static async byVendorId(
        userId: number,
        { uuid: vendorId }: { uuid: string }
    ): Promise<Account[]> {
        return await Account.repo().find({ userId, vendorId });
    }

    static async findMany(userId: number, accountIds: number[]): Promise<Account[]> {
        return await Account.repo().find({ userId, id: In(accountIds) });
    }

    static async byAccess(userId: number, access: Access | { id: number }): Promise<Account[]> {
        return await Account.repo().find({ userId, accessId: access.id });
    }

    // Doesn't insert anything in db, only creates a new instance and normalizes its fields.
    static cast(args: Partial<Account>): Account {
        return Account.repo().create(args);
    }

    static async create(userId: number, attributes: Partial<Account>): Promise<Account> {
        const entity = Account.repo().create({ userId, ...attributes });
        return await Account.repo().save(entity);
    }

    static async find(userId: number, accessId: number): Promise<Account | undefined> {
        return await Account.repo().findOne({ where: { userId, id: accessId } });
    }

    static async all(userId: number): Promise<Account[]> {
        return await Account.repo().find({ userId });
    }

    static async exists(userId: number, accessId: number): Promise<boolean> {
        const found = await Account.repo().findOne({ where: { userId, id: accessId } });
        return !!found;
    }

    static async destroy(userId: number, accessId: number): Promise<void> {
        await Account.repo().delete({ userId, id: accessId });
    }

    static async destroyAll(userId: number): Promise<void> {
        await Account.repo().delete({ userId });
    }

    static async update(
        userId: number,
        accountId: number,
        attributes: Partial<Account>
    ): Promise<Account> {
        await Account.repo().update({ userId, id: accountId }, attributes);
        return unwrap(await Account.find(userId, accountId));
    }
}
