# Rapport de bug

Merci de compléter tous les champs suivants, dans la mesure du possible, et de
décrire le plus précisément possible votre souci.

Version de Weboob que j'utilise : [compléter]
Version de Kresus que j'utilise : [compléter]
Les étapes à faire pour reproduire le bug : [compléter]
Ce que je m'attends à voir : [compléter]
Ce que j'observe en pratique : [compléter]
Mes logs côté client (s'ils s'appliquent) : [compléter]
Mes logs côté serveur (s'ils s'appliquent) : [compléter]
