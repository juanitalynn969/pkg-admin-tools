# Bug report

Thanks for filling all the following fields, if they apply, and to describe
your issue the most precisely you can.

Weboob's version I am using is: [fill here]
Kresus's version I am using is: [fill here]
Steps to reproduce: [fill here]
What I expect: [fill here]
What I observe: [fill here]
Client logs (if apply): [fill here]
Server logs (if apply): [fill here]
