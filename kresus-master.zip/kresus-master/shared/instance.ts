// Instance properties
export const CAN_ENCRYPT = 'can-encrypt';
export const EMAILS_ENABLED = 'emails-enabled';
export const NOTIFICATIONS_ENABLED = 'notifications-enabled';
export const FORCE_DEMO_MODE = 'force-demo-mode';
export const URL_PREFIX = 'url-prefix';
export const WEBOOB_INSTALLED = 'weboob-installed';
export const WEBOOB_VERSION = 'weboob-version';
