import React from 'react';

import './form-toolbar.css';

export default function FormToolbar(props) {
    return <p className="form-toolbar">{props.children}</p>;
}
