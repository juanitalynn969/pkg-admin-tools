import React from 'react';
import { NavLink } from 'react-router-dom';

import URL from '../../urls';
import { translate as $t } from '../../helpers';

import DisplayIf from '../ui/display-if';

import './dropdown.css';

class DropdownContent extends React.PureComponent {
    componentDidMount() {
        document.addEventListener('keydown', this.props.onKeydown);
    }

    componentWillUnmount() {
        document.removeEventListener('keydown', this.props.onKeydown);
    }

    render() {
        return (
            <div id={this.props.id} onClick={this.props.onClick}>
                {this.props.children}
            </div>
        );
    }
}

export default class DropdownMenu extends React.PureComponent {
    state = {
        show: false,
    };

    handleHide = () => {
        this.setState({ show: false });
    };

    handleToggle = () => {
        this.setState({ show: !this.state.show });
    };

    handleKeydown = event => {
        if (event.key === 'Escape') {
            this.handleHide();
        }
    };

    render() {
        return (
            <div className="settings-dropdown">
                <button className="fa fa-cogs" onClick={this.handleToggle} />
                <DisplayIf condition={this.state.show}>
                    <DropdownContent
                        id="overlay"
                        onKeydown={this.handleKeydown}
                        onClick={this.handleHide}>
                        <nav className="settings-dropdown-menu">
                            <ul>
                                <li>
                                    <NavLink to={URL.dashboard.url()}>
                                        <span className="fa fa-dashboard" />
                                        {$t('client.menu.dashboard')}
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to={URL.categories.pattern}>
                                        <span className="fa fa-list-ul" />
                                        {$t('client.menu.categories')}
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to={URL.accesses.url()}>
                                        <span className="fa fa-bank" />
                                        {$t('client.settings.tab_accesses')}
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to={URL.settings.url('emails')}>
                                        <span className="fa fa-envelope" />
                                        {$t('client.settings.tab_alerts')}
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to={URL.settings.url('backup')}>
                                        <span className="fa fa-save" />
                                        {$t('client.settings.tab_backup')}
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to={URL.settings.url('admin')}>
                                        <span className="fa fa-sliders" />
                                        {$t('client.settings.tab_admin')}
                                    </NavLink>
                                </li>
                                <li>
                                    <NavLink to={URL.settings.url('customization')}>
                                        <span className="fa fa-paint-brush" />
                                        {$t('client.settings.tab_customization')}
                                    </NavLink>
                                </li>
                            </ul>
                            <ul>
                                <li>
                                    <NavLink to={URL.about.url()}>
                                        <span className="fa fa-question" />
                                        {$t('client.menu.about')}
                                    </NavLink>
                                </li>
                            </ul>
                        </nav>
                    </DropdownContent>
                </DisplayIf>
            </div>
        );
    }
}
