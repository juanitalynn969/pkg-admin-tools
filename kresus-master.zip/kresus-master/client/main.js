import React, { Suspense } from 'react';
import ReactDOM from 'react-dom';
import {
    BrowserRouter,
    Route,
    Switch,
    Link,
    Redirect,
    useRouteMatch,
    useParams,
    useLocation,
} from 'react-router-dom';
import { connect, Provider } from 'react-redux';
import throttle from 'lodash.throttle';
import { ToastContainer } from 'react-toastify';

// Global variables
import { get, init, rx, actions } from './store';
import { translate as $t, debug, computeIsSmallScreen } from './helpers';
import URL from './urls';
import { FORCE_DEMO_MODE, URL_PREFIX } from '../shared/instance';
import { LOCALE } from '../shared/settings';

// Components
import About from './components/about';
import OperationList from './components/operations';
import Budget from './components/budget';
import DuplicatesList from './components/duplicates';
import Settings from './components/settings';
import Accesses from './components/accesses';
import Categories from './components/categories';

import Onboarding from './components/onboarding';

import Dashboard from './components/dashboard';
import Menu from './components/menu';
import DropdownMenu from './components/menu/dropdown';

import DemoButton from './components/header/demo-button';

import DisplayIf from './components/ui/display-if';
import ErrorReporter from './components/ui/error-reporter';
import { LoadingMessage, LoadingOverlay } from './components/ui/loading';
import Modal from './components/ui/modal';
import withCurrentAccountId from './components/withCurrentAccountId';

import 'normalize.css/normalize.css';
import 'font-awesome/css/font-awesome.css';
import 'react-toastify/dist/ReactToastify.min.css';
import './css/base.css';

const RESIZE_THROTTLING = 100;

// Lazy-loaded components
const ChartsComp = React.lazy(() => import('./components/charts'));

const Charts = props => {
    return (
        <Suspense fallback={<LoadingMessage message={$t('client.spinner.loading')} />}>
            <ChartsComp {...props} />
        </Suspense>
    );
};

const SectionTitle = () => {
    let titleKey = URL.sections.title(useParams());
    if (titleKey === null) {
        return null;
    }
    let title = $t(`client.menu.${titleKey}`);
    return <span className="section-title">&nbsp;/&nbsp;{title}</span>;
};

const RedirectIfUnknownAccount = withCurrentAccountId(
    connect((state, props) => {
        return {
            isUnknownAccount: get.accountById(state, props.currentAccountId) === null,
            initialAccountId: get.initialAccountId(state),
        };
    })(props => {
        let location = useLocation();
        let { isUnknownAccount } = props;

        if (isUnknownAccount) {
            let { currentAccountId, initialAccountId } = props;
            return (
                <Redirect
                    to={location.pathname.replace(currentAccountId, initialAccountId)}
                    push={false}
                />
            );
        }
        return props.children;
    })
);

class BaseApp extends React.Component {
    handleWindowResize = throttle(event => {
        let isSmallScreen = computeIsSmallScreen(event.target.innerWidth);
        if (isSmallScreen !== this.props.isSmallScreen) {
            this.props.setIsSmallScreen(isSmallScreen);
        }
    }, RESIZE_THROTTLING);

    componentDidMount() {
        window.addEventListener('resize', this.handleWindowResize);

        // Preload the components
        /* eslint-disable-next-line no-unused-expressions*/
        import('./components/charts');
    }

    componentWillUnmount() {
        window.removeEventListener('resize', this.handleWindowResize);
    }

    render() {
        let handleContentClick = this.props.isSmallScreen ? this.props.hideMenu : null;

        let { initialAccountId } = this.props;

        return (
            <React.Fragment>
                <Modal />
                <header>
                    <button className="menu-toggle" onClick={this.props.handleToggleMenu}>
                        <span className="fa fa-navicon" />
                    </button>
                    <h1>
                        <Link to={URL.dashboard.url()}>{$t('client.KRESUS')}</Link>
                    </h1>
                    <Route path={URL.sections.pattern}>
                        <SectionTitle />
                    </Route>

                    <DisplayIf condition={this.props.forcedDemoMode}>
                        <p className="disable-demo-mode">{$t('client.demo.forced')}</p>
                    </DisplayIf>
                    <DisplayIf condition={!this.props.forcedDemoMode}>
                        <DemoButton />
                    </DisplayIf>

                    <DropdownMenu />
                </header>

                <main>
                    <Route path={URL.sections.genericPattern}>
                        <Menu />
                    </Route>
                    <div id="content-container">
                        <div id="content" onClick={handleContentClick}>
                            <Switch>
                                <Route path={URL.reports.pattern}>
                                    <RedirectIfUnknownAccount>
                                        <OperationList />
                                    </RedirectIfUnknownAccount>
                                </Route>
                                <Route path={URL.budgets.pattern}>
                                    <RedirectIfUnknownAccount>
                                        <Budget />
                                    </RedirectIfUnknownAccount>
                                </Route>
                                <Route path={URL.charts.pattern}>
                                    <RedirectIfUnknownAccount>
                                        <Charts />
                                    </RedirectIfUnknownAccount>
                                </Route>
                                <Route path={URL.duplicates.pattern}>
                                    <DuplicatesList />
                                </Route>
                                <Route path={URL.settings.pattern}>
                                    <Settings />
                                </Route>
                                <Route path={URL.categories.pattern}>
                                    <Categories />
                                </Route>
                                <Route path={URL.about.pattern}>
                                    <About />
                                </Route>
                                <Route path={URL.accesses.pattern}>
                                    <Accesses />
                                </Route>
                                <Route path={URL.dashboard.pattern}>
                                    <Dashboard />
                                </Route>
                                <Redirect to={URL.reports.url(initialAccountId)} push={false} />
                            </Switch>
                        </div>
                    </div>
                </main>
            </React.Fragment>
        );
    }
}

const Kresus = connect(
    state => {
        let initialAccountId = get.initialAccountId(state);
        return {
            forcedDemoMode: get.boolInstanceProperty(state, FORCE_DEMO_MODE),
            initialAccountId,
            isSmallScreen: get.isSmallScreen(state),
        };
    },
    dispatch => {
        return {
            setIsSmallScreen(isSmallScreen) {
                actions.setIsSmallScreen(dispatch, isSmallScreen);
            },
            handleToggleMenu() {
                actions.toggleMenu(dispatch);
            },
            hideMenu() {
                actions.toggleMenu(dispatch, true);
            },
        };
    }
)(BaseApp);

const DisplayOrRedirectToInitialScreen = connect(state => {
    return {
        hasAccess: get.accessIds(state).length > 0,
        isWeboobInstalled: get.isWeboobInstalled(state),
    };
})(props => {
    let isWeboobReadmeDisplayed = useRouteMatch({ path: URL.weboobReadme.pattern });
    let isOnboardingDisplayed = useRouteMatch({ path: URL.onboarding.pattern });

    if (!props.isWeboobInstalled) {
        if (!isWeboobReadmeDisplayed) {
            return <Redirect to={URL.weboobReadme.url()} push={false} />;
        }
    } else if (!props.hasAccess) {
        if (!isOnboardingDisplayed) {
            return <Redirect to={URL.onboarding.url()} push={false} />;
        }
    } else if (isWeboobReadmeDisplayed || isOnboardingDisplayed) {
        return <Redirect to="/" push={false} />;
    }

    return props.children;
});

const TranslatedApp = connect(state => {
    return {
        // Force re-rendering when the locale changes.
        locale: get.setting(state, LOCALE),
    };
})(() => {
    return (
        <ErrorReporter>
            <Switch>
                <Route path={[URL.weboobReadme.pattern, URL.onboarding.pattern]}>
                    <DisplayOrRedirectToInitialScreen>
                        <Onboarding />
                    </DisplayOrRedirectToInitialScreen>
                </Route>
                <Route path="/" exact={false}>
                    <DisplayOrRedirectToInitialScreen>
                        <Kresus />
                    </DisplayOrRedirectToInitialScreen>
                </Route>
                <Redirect from="" to="/" push={false} />
            </Switch>

            <ToastContainer />
            <LoadingOverlay />
        </ErrorReporter>
    );
});

export default function runKresus() {
    init()
        .then(initialState => {
            Object.assign(rx.getState(), initialState);

            const appElement = document.getElementById('app');

            // Remove the loading class on the app element.
            appElement.classList.remove('before-load');

            let urlPrefix = get.instanceProperty(initialState, URL_PREFIX);

            // Remove trailing '/'
            urlPrefix = urlPrefix.replace(/\/$/g, '');

            ReactDOM.render(
                <BrowserRouter basename={`${urlPrefix}/#`}>
                    <Provider store={rx}>
                        <TranslatedApp />
                    </Provider>
                </BrowserRouter>,
                appElement
            );
        })
        .catch(err => {
            let errMessage = '';
            if (err) {
                debug(err);
                errMessage = `\n${err.shortMessage || JSON.stringify(err)}`;
            }
            window.alert(`Error when starting the app:${errMessage}\nCheck the console.`);
        });
}
